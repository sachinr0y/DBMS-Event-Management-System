#### Roadmap

- [x] login
- [x] event_table
- [x] bill
- [x] account_table
- [x] registration
- [x] sponsorship_package
- [x] sponsors
- [x] vendors
- [x] department
- [ ] team
- [x] feedback
- [x] inventory


### To-Do List
# Absolutely Necessary
Update Function
Report
ER-Diagram
## Less priority
Function Button
Login Mechanism
